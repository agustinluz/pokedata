export interface Pokemon {
  id: number;
  nombre: string;
  imagen: string;
  tipos: string[];
  habilidades: string[];
  peso: string;
  altura: string;
}